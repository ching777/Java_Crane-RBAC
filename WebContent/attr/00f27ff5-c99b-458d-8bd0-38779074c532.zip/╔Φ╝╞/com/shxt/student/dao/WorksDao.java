/**
 * WorksDao.java
 * ©2006-2016 四海兴唐科技有限公司 
 * All rights reserved.
 * <link>胖先生作品</link>
 * 创建于: 2017-02-12 12:53:33
 **/
package com.shxt.student.dao;

import com.shxt.student.model.Works;

public interface WorksDao {
    /**
     * answer_works_manage
     * 方法描述:
     * @param  
     * @return 
     * @throws 
     * @author 胖先生
     * @date 2017-02-12 12:53:33
     * 
     **/
    int delete(String works_id);

    /**
     * answer_works_manage
     * 方法描述:
     * @param  
     * @return 
     * @throws 
     * @author 胖先生
     * @date 2017-02-12 12:53:33
     * 
     **/
    int add(Works works);

    /**
     * answer_works_manage
     * 方法描述:
     * @param  
     * @return 
     * @throws 
     * @author 胖先生
     * @date 2017-02-12 12:53:33
     * 
     **/
    Works load(String works_id);

    /**
     * answer_works_manage
     * 方法描述:
     * @param  
     * @return 
     * @throws 
     * @author 胖先生
     * @date 2017-02-12 12:53:33
     * 
     **/
    int update(Works works);
}